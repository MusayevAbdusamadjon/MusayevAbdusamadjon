

create database wending_machine;

set search_path to public;


create schema products;
create schema transactions;

set search_path to products;

create table products(
    product_id serial primary key ,
    product_name varchar,
    price decimal(10, 2) not null ,
    stock int not null ,
    is_exist boolean
);

set search_path to wending_machine, transactions;

create table transactions(
    transaction_id serial primary key ,
    product_id int references products.products(product_id),
    quantity int not null,
    total_price decimal(10, 2) not null ,
    transaction_date timestamp default current_timestamp
);


create procedure add_product(p_name varchar, p_price decimal, p_stock int)
language plpgsql
as
    $$
    begin
        insert into products (product_name, price, stock) values (p_name, p_price, p_stock);
    end;
    $$;

set search_path to products;
CREATE  PROCEDURE purchase_product(p_id INT, p_quantity INT)
LANGUAGE plpgsql
AS $$
DECLARE
    v_price DECIMAL(10, 2);
    v_stock INT;
BEGIN

    SELECT price, stock INTO v_price, v_stock FROM products WHERE product_id = p_id;

    IF v_stock < p_quantity THEN
        RAISE EXCEPTION 'Yetarli mahsulot mavjud emas.';
    ELSE

        UPDATE products SET stock = stock - p_quantity WHERE product_id = p_id;

        INSERT INTO transactions (product_id, quantity, total_price)
        VALUES (p_id, p_quantity, v_price * p_quantity);
    END IF;
END;
$$;

CREATE OR REPLACE FUNCTION view_products()
RETURNS TABLE(product_id INT, product_name VARCHAR, price DECIMAL, stock INT)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY SELECT product_id, product_name, price, stock FROM products;
END;
$$;

CREATE OR REPLACE FUNCTION total_sales()
RETURNS DECIMAL(10, 2)
LANGUAGE plpgsql
AS $$
DECLARE
    v_total DECIMAL(10, 2);
BEGIN
    SELECT SUM(total_price) INTO v_total FROM transactions;
    RETURN v_total;
END;
$$;



CALL add_product('Cola', 1.50, 100);
CALL add_product('Pepsi', 1.40, 50);


SELECT * FROM products.products;


CALL purchase_product(2, 50); 


SELECT total_sales();
